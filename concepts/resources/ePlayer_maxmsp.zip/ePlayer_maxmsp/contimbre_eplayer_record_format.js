sketch.ortho3d(); //like default3d but uses orthographic projection
var vbrgb = [jsarguments[1],jsarguments[2],jsarguments[3],0];
var textsv=["Stereo","8 chn.","32 chn.","Mono"];
var textv = "Stereo";
var format_state = 0;
var top_patcher=this.patcher;
var record_box;
var record_state = 0;  //0="no",1= "ready",2= "yes"
var idle_state=false;
var vfrgb=new Array(3);

var rgb = [
  [0.74,0.8,0.12],
  [0.91,0.65,0.6 ],
  [0.91,0.35,0.35 ]
];

var rgb_idle = [
  [0.84,0.8,0.32],
  [0.96,0.70,0.65],
  [0.96,0.50,0.5]
];

function getrgb(lrgb)
{
    vfrgb[0] = lrgb[record_state][0];
    vfrgb[1] = lrgb[record_state][1];
    vfrgb[2] = lrgb[record_state][2];
}

getrgb(rgb);

var ready_to_record_rgb = [0.91,0.65,0.6 ];
var ready_to_record_idle_rgb = [0.96,0.70,0.65];

function draw(lylight)
{
     var theta;
    var width = box.rect[2] - box.rect[0];
    var height = box.rect[3] - box.rect[1];
    var roundness = 0.5;
    var cylinderwidth = width - roundness*height;
    var aspect = cylinderwidth/height;

        with (sketch) {
            glclearcolor(vbrgb);
            glclear();  
            glloadidentity();          
            glcolor(vfrgb);
           // gllight(0,"position",0,lylight*aspect,20*aspect,8.5);
           shapeorient(0,90,90);    
               moveto(0,0,0);
           cylinder(1,1,aspect);      
            font("Sans Serif");                  
            fontsize(11);                  
             textalign("center","center");
             moveto(0,0.1,0);
             glcolor(0,0,0);
             text(textv);
                moveto(aspect/roundness,0,0);
            glcolor(vfrgb);
            glscale(roundness,1,1);
           shapeorient(0,90,0);    
             sphere(1,0,360,0,90);                        
            moveto(-aspect/roundness,0,0);
           shapeorient(0,-90,0);   
            sphere(1,0,360,0,90);                        
       }
}

function mono_text()
{
  textsv[3] = arguments[0];
  for (var i=1;i<arguments.length;i++)
  {
    textsv[3] = textsv[3]+" "+arguments[i];
  }
}


function stereo_text()
{
  textsv[0] = arguments[0];
  for (var i=1;i<arguments.length;i++)
  {
    textsv[0] = textsv[0]+" "+arguments[i];
  }
}

function ch8_text()
{
  textsv[1] = arguments[0];
  for (var i=1;i<arguments.length;i++)
  {
    textsv[1] = textsv[1]+" "+arguments[i];
  }
}

function ch32_text()
{
  textsv[2] = arguments[0];
  for (var i=1;i<arguments.length;i++)
  {
    textsv[2] = textsv[2]+" "+arguments[i];
  }
}

function init()
{
    var owner; 
    owner = this.patcher.parentpatcher; 
    while (owner) { 
        top_patcher = owner; 
        owner = owner.parentpatcher; 
    } 
  record_box = top_patcher.getnamed("record");
  textv = textsv[format_state];
  record_box.message("channel_mode",format_state);
  draw(10);
  refresh();
}

function onclick()
{
  format_state+=1;
  format_state = format_state%4;
  textv=  textsv[format_state];
  record_box.message("channel_mode",format_state);
  draw(10);
  refresh();
}

function set_record_state (lstate)
{
  record_state = lstate;
  getrgb(rgb);
  draw(10);
  refresh();
}

function animation (fraction)
{
  var oneminusfraction = 1-fraction;
  if (idle_state)
  {
    vfrgb[0] = 1*oneminusfraction+ready_to_record_idle_rgb[0]*fraction;
    vfrgb[1] = 0.3*oneminusfraction+ready_to_record_idle_rgb[1]*fraction;
    vfrgb[2] = 0.3*oneminusfraction+ready_to_record_idle_rgb[2]*fraction;
  }
  else
  {
    vfrgb[0] = 1*oneminusfraction+ready_to_record_rgb[0]*fraction;
    vfrgb[1] = 0*oneminusfraction+ready_to_record_rgb[1]*fraction;
    vfrgb[2] = 0*oneminusfraction+ready_to_record_rgb[2]*fraction;
  }

  draw(10);
  refresh();
}

function onidle()
{
  idle_state=true;
  if (record_state!=1)
  {
    getrgb(rgb_idle);
    draw(10);
    refresh();
  }
}

function onidleout()
{
  idle_state=false;
  if (record_state!=1)
  {
    getrgb(rgb);
    draw(10);
    refresh();
  }
}
