outlets = 3;
var currentVersion=0;
var currentInstallerVersion="";
var VersionChangesPath="";
var language = "english";
function set (lstr)
{
	if (arguments[0]=="f0fs24")
	{
		currentVersion=parseFloat(arguments[2].substring(1));
	}
}

function VersionData (lstr)
{
	var pos1=0;
	var pos2=0;
	var VersionChanges = "VersionChanges";
	var vlLength = VersionChanges.length;
	// find conTimbre version which is in line 2
	for (var pos1=0;pos1<lstr.length;pos1++)
	{
		if (lstr.charCodeAt(pos1)==10) break;
	}
	currentInstallerVersion=lstr.substring(9,pos1);
	for (var pos2=pos1+1;pos2<lstr.length;pos2++)
	{
		if (lstr.charCodeAt(pos2)==10) break;
	}
	var lstr1 = lstr.substring(pos1+2,pos2);
	var available=parseFloat(lstr1);
	if (available>currentVersion)
	{
		outlet(0,"availableVersion",available);
	}
	// find version change path
	for (pos1=0;pos1<lstr.length;pos1++)
	{
		if (lstr.substring(pos1,pos1+vlLength)==VersionChanges) break;
	}
	for (pos2=pos1+1+vlLength;pos2<lstr.length;pos2++)
	{
		if (lstr.charCodeAt(pos2)==10) break;
	}
	VersionChangesPath= lstr.substring(pos1+vlLength+1,pos2);
}

function download ()
{
		outlet(1,"defaultdir");
		outlet(1,"download","https://www.contimbre.com/files/software/conTimbreInstallerUpdaterSiliconMac"+currentInstallerVersion+".zip");
}

function setLanguage (llanguage)
{
	language=llanguage;
	
}

function moreInfo ()
{
	var languageAbbreviation = "DE";
	if (language!="german") languageAbbreviation="EN";
	outlet(2,VersionChangesPath+"/VersionChanges"+languageAbbreviation+".htm");
}
