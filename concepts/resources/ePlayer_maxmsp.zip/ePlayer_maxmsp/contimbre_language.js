var master;
var current_language;

var is_idle = false;
var idle_on_flag = true;
var my_number;
var master;

function no_idle ()
{
  idle_on_flag = false;
}

function ok_idle ()
{
  idle_on_flag = true;
}

function draw ()
{
  var vfrgb = [181.0/256.0,238.0/256.0,232.0/256.0,1.];
		with (sketch) {
		glclearcolor(vfrgb);			
		glclear();			
	refresh();
		
	}
}

function init (llanguage)
{
    current_language = llanguage;
    var top_patcher = this.patcher; 
    master = top_patcher.getnamed("core").subpatcher().getnamed("audio");
    draw();
}

function onidle (x, y, button, mod1, shift, caps, opt, mod2)
{
  if (!is_idle && idle_on_flag) {
    master.message("language_idle",current_language);
    is_idle = true;
  }
}

function onidleout (x, y, button, mod1, shift, caps, opt, mod2)
{
    master.message("language_idle_out",current_language);
    is_idle = false;
}

function onclick(x,y,but,cmd,shift,capslock,option,ctrl)
{
    master.message("set_language_language",current_language);
}
