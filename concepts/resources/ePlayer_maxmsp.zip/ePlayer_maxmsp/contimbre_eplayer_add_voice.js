// 0 18 plusbox
// 17 17 checkbox
// 33 159 voicename
// 191 335 instrumentmodes
// 526 41 solomute
// 567 overall length
    var color_index = 0;
    var is_checked=true;

    var width = box.rect[2] - box.rect[0];
    var height = box.rect[3] - box.rect[1];
    var aspect = width/height;
    var is_idle=false;
    function convert_x(lx)
    {
        return((lx/width*2-1)*aspect);
    }
    
    color = new Array(0.999, 0.9, 0.968438);
    
var xlight = 0.05;
var ylight = 0.5;
var zlight = 2.0;
var alight = 0.0;
var my_number=0;

function draw()
{
    with (sketch) {
        glclear();  
        glcolor(0.999, 0.9, 0.968438);
        var lx1 = -1*aspect;
        var lx2 = 1*aspect;
        quad(lx1,-1,0,lx1,1,0,lx2,1,0,lx2,-1,0);
        font("Sans Serif");
        fontsize(20);   
        if (is_idle)               
            glcolor(0,0,0);
        else
            glcolor(.7,.7,.7);
        textalign("center","center");
        moveto(0,0);
        text("+");
        refresh();
    }         
}

draw();
function set_number(lnum)
{
    my_number = lnum;
}

function onidle(x,y,but,cmd,shift,capslock,option,ctrl)
{
    is_idle=true;
    draw();
}

function onidleout(x,y,but,cmd,shift,capslock,option,ctrl)
{
    is_idle=false;
    draw();
}

function onclick(x,y,but,cmd,shift,capslock,option,ctrl)
{
    var owner; 
    var top_patcher= this.patcher;
    owner = this.patcher.parentpatcher; 
    while (owner) { 
        top_patcher = owner; 
        owner = owner.parentpatcher; 
    } 
    master_mxj = top_patcher.getnamed("core").subpatcher().getnamed("audio");
    master_mxj.message("add_voice_to_orchestra",my_number);
}

