var width = box.rect[2] - box.rect[0];
var height = box.rect[3] - box.rect[1];
var aspect = width/height;
var keyboard_length = 128;
var playing_modes = new Array(keyboard_length);
var possible_modes = new Array(keyboard_length);
for (var i=0;i<keyboard_length;i++)
{
  playing_modes[i]=1;
  possible_modes[i]=3;
}
  playing_modes[0]=0;
var texts = new Array("->","->->","<->");
var is_idle = -2;
var old_is_idle = -2;

function draw()
{
    with (sketch) {
        glclear();            
            font("Sans Serif");                  
            fontsize(10);                  
             textalign("center","center");
        for (var minusi=0;minusi<keyboard_length;minusi++)
        {
            var i = minusi;
            var ly = i/keyboard_length;
            var ldy = 1/keyboard_length;
            ly1 = ly*2-1;
            ly2 = (ly+ldy)*2-1;
            var lx1 = -1*aspect;
            var lx2 = 1*aspect;
           if (minusi==is_idle)
           {
             glcolor(.99,0.94,0.0);
           }
           else
           {
             glcolor(.99,.99,0.7);
            }
            quad(lx1,ly1,0,lx1,ly2,0,lx2,ly2,0,lx2,ly1,0);
           glcolor(0.,0.,0.);
           framequad(lx1,ly1,0,lx1,ly2,0,lx2,ly2,0,lx2,ly1,0);
           moveto((4/width*2-.3)*aspect,(ly1+ly2)/2);
           text(texts[playing_modes[i]]);
       }
        refresh();
     }
  }

function onidle(x,y,but,cmd,shift,capslock,option,ctrl)
{
    is_idle = keyboard_length - 1 - Math.floor(y/height*keyboard_length);
    if (is_idle != old_is_idle) draw();
    old_is_idle = is_idle;
}

function onidleout(x,y,but,cmd,shift,capslock,option,ctrl)
{
    is_idle = -2;
    old_is_idle = -2;
    draw();
}

function onclick(x,y,but,cmd,shift,capslock,option,ctrl)
{
    var pitch = keyboard_length - 1 - Math.floor(y/height*keyboard_length);
    if ((option==1)||(ctrl==1))
    {
      all_play= (playing_modes[pitch]+1)%possible_modes[pitch];
      for (var i=0;i<keyboard_length;i++)
      {
        if (all_play>=possible_modes[i])
          playing_modes[i]=possible_modes[i]-1;
        else
          playing_modes[i]=all_play;
        outlet(0,"playing_mode",i,playing_modes[i]);
      }
    }
    else
    {
      playing_modes[pitch]=(playing_modes[pitch]+1)%possible_modes[pitch];
        outlet(0,"playing_mode",pitch,playing_modes[pitch]);
    } 
    draw();
}

function possible()
{
  for (var i=0;i<keyboard_length;i++)
  {
     possible_modes[i]=arguments[i];
  }
}

function all()
{
  for (var i=0;i<keyboard_length;i++)
  {
     playing_modes[i]=arguments[i];
  }
  draw();
}
draw();