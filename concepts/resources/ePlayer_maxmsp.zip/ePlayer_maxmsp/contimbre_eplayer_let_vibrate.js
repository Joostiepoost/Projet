//// let_vibrate.js /////////////
////////started 16.12.2012 /////////////

var top_patcher;

var is_idle = false;
var master;
var width = box.rect[2] - box.rect[0];
var height = box.rect[3] - box.rect[1];
var aspect = width/height;
var let_vibrate = false;
var is_idle = -2;
var old_is_idle = -2;
var keyboard_length = 128;
var let_vibrate = new Array(keyboard_length);
for (var i=0;i<keyboard_length;i++)
{
    let_vibrate[i]=false;
}

inlets = 1;
outlets = 1;
sketch.default2d();

function set(onoff)
{
  for (var i=0;i<keyboard_length;i++)
  {
     let_vibrate[i]=(arguments[i]!=0);
  }
  draw();
}

function draw()
{
    with (sketch) {
      glclear();  
        for (var minusi=0;minusi<keyboard_length;minusi++)
        {
            var i = minusi;
            var ly = i/keyboard_length;
            var ldy = 1/keyboard_length;
            ly1 = ly*2-1;
            ly2 = (ly+ldy)*2-1;
			var lymean = (ly1+ly2)/2.;
            var lx1 = -1*aspect;
            var lx2 = 1*aspect;
      if (minusi==is_idle)
        glcolor(.99,.99,0.7);
      else
      {
        if (let_vibrate[minusi])
        {
           glcolor(.99,.99,0.5);
        }
        else
        {
           glcolor(.99,.99,0.9);
        }
      }
           quad(lx1,ly1,0,lx1,ly2,0,lx2,ly2,0,lx2,ly1,0);
           gllinewidth(1.);
           glcolor(0.,0.,0.);
           framequad(lx1,ly1,0,lx1,ly2,0,lx2,ly2,0,lx2,ly1,0);
		beginstroke("basic2d");
        if (let_vibrate[minusi])
        {
 		gllinewidth(3);
        }
        else
        {
		gllinewidth(1);
		}
      for (i=0;i<width;i++)
      {
		var fract = i/width;
		var fract1 = i/width - .2;
		if (fract1<0) fract1 = 0;
        var theta = Math.cos(fract*Math.PI*6);
		strokepoint(aspect*(i*2/(width-1)-1),theta*.9*Math.pow(0.05,fract1)/128+lymean);
      }
      endstroke();
      refresh();
    }
    }
}

function onclick(x,y,but,cmd,shift,capslock,option,ctrl)
{
    var pitch = keyboard_length - 1 - Math.floor(y/height*keyboard_length);
    let_vibrate[pitch] = !let_vibrate[pitch];
    if (option==1)
    {
        for (var i=0;i<keyboard_length;i++)
        {
          let_vibrate[i] = let_vibrate[pitch];
        }
        if (let_vibrate[pitch])
            outlet(0,"let_vibrate_all",1);
        else
            outlet(0,"let_vibrate_all",0);
    }
    else
    {
       if (let_vibrate[pitch])
          outlet(0,"let_vibrate",pitch,1);
       else
          outlet(0,"let_vibrate",pitch,0);
    }
    draw();
}

function onidle(x,y,but,cmd,shift,capslock,option,ctrl)
{
    is_idle = keyboard_length - 1 - Math.floor(y/height*keyboard_length);
    if (is_idle != old_is_idle) draw();
    old_is_idle = is_idle;
}

function onidleout(x,y,but,cmd,shift,capslock,option,ctrl)
{
    is_idle = -2;
    old_is_idle = -2;
    draw();
}

function init()
{
    draw();
}

function onresize(x,y)
{
width = box.rect[2] - box.rect[0];
height = box.rect[3] - box.rect[1];
aspect = width/height;
    draw();
}
draw();