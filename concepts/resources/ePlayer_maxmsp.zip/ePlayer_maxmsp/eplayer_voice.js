sketch.ortho3d(); //like default3d but uses orthographic projection

var colors = new Array(
           new Array(.42,.76,.95),
           new Array(.96,.44,.48),
           new Array(.76,.82,.57),
           new Array(.92,.94,.67),
           new Array(.93,.58,1.00),
           new Array(.93,.36,.87),
           new Array(.28,.92,.84),
           new Array(.95,.91,.41)
);

var eplayer;
var maxVoices = 128;
var voicenameDx = 158;
var modesX0 = 176.;
var width  = box.rect[2] - box.rect[0];
var height = box.rect[3] - box.rect[1];
var x0 = box.rect[0];
var y0 = box.rect[1];
var dy = height/maxVoices;

var xlight = -0.5;
var ylight = 0.5;
var zlight = 2.0;
var alight = 0.0;

var mouseX=0;
var mouseY=0;
var mousemetro = this.patcher.getnamed("mousemetro");
var aspect = width/height;
var idleIndex=-1;
var dragIndex=-1;
var oldIdleIndex=-1;
var oldDragIndex=-1;
var drawtask;
var drawTaskIsScheduled=false;
var needToDraw=true;
var selectionStart=-1;
var selectionEnd  =-1;
var selectedArray = new Array();
var dragging=false;
var justClicked=false;

var voices = new Array();
var current_colors = new Array(3);

var owner; 
var top_patcher= this.patcher;

owner = this.patcher.parentpatcher; 
while (owner) { 
   top_patcher = owner; 
   owner = owner.parentpatcher; 
} 

for (var i=0;i<maxVoices;i++)
{
	var i1=i+1;
	voices.push(new Array(false,false,"voice"+i1,"mode"+i1,0,false,true));
}

/*
  voice:
  0: idle true/false
  1: selected true/false
  2: voice name
  3: program name
  4: color index
  5: hidden
  6: voicename_is_midi_device
*/

function delete_voices_in_orchestra()
{
	if (selectionArray.length>0)
	{
		top_patcher.getnamed("core").subpatcher().getnamed("audio").message("delete_voices_in_orchestra",selectionArray);
	}
}

function want_to_delete_voices()
{
	if (selectionArray.length>0)
	{
		top_patcher.getnamed("manage").subpatcher().getnamed("delete_voices").subpatcher().getnamed("thispatcher").message("front");
	}
}

function deselect()
{
			for (var i=0;i<maxVoices;i++)
			{
				voices[i][1]=false; // selected
			}
 			selectionArray = new Array();
  			selectionStart=-1;
			selectionEnd  =-1;
			dragging = false;
			delayedDraw();
}

function bgcolor (lvoice,lcolorIndex)
{
	voices[lvoice][4]=lcolorIndex;
	delayedDraw();
}

function programtext (lvoice,ltext)
{
	voices[lvoice][3]=ltext;
	delayedDraw();
}

function setname (lvoice,ltext,lisMIDIDevice)
{
	voices[lvoice][2]=ltext;
	voices[lvoice][6]=(lisMIDIDevice=="true");
	delayedDraw();
}

function sethidden (lvoice,lhidden)
{
	if (lhidden=="true") voices[lvoice][5]=true;
	else voices[lvoice][5]=false;
	delayedDraw();
}

function onidle(x,y,but,cmd,shift,capslock,option,ctrl)
{
  mousemetro.message(1);
}

function onidleout(x,y,but,cmd,shift,capslock,option,ctrl)
{
  idleIndex=-1;
  oldIdleIndex=-1;
  oldDragIndex=-1000;
  mousemetro.message(0);
  delayedDraw();
}
  
function convert_x(lx)
{
    return((lx/width*2-1)*1.115*aspect);
}
   
function convert_y(ly)
{
    return(ly/height*2-1);
}

function draw()
{
	if (needToDraw)
	{
		with (sketch) {
        	glclearcolor(0.999, 0.999, 0.999,0); // no opacity
        	glclear();  
        	glloadidentity();   
			for (i=0;i<maxVoices;i++)
			{
 				gllightmodel();       
     			gllight(0,"position",xlight,ylight,zlight,alight);
				var voice     = voices[i];
				var selected   = voice[1];
				var name       = voice[2];
				var mode       = voice[3];
				var color_index = voice[4];
				var hidden     = voice[5];
				var mididevice = voice[6];
				var dz=0.003;
				var spaceDy=0;
				if ((i==oldDragIndex)&&dragging) spaceDy=-3;
			
				var currentY = (maxVoices-i-1)/(maxVoices-1)*(height-dy);
				if (!hidden)
				{
              		if ((i==idleIndex)&&(!selected))
              		{
                		current_colors[0]=1-(1-colors[color_index][0])*.8;
                		current_colors[1]=1-(1-colors[color_index][1])*.8;
                		current_colors[2]=1-(1-colors[color_index][2])*.8;
              		}
              		if ((i!=idleIndex)&&(!selected))
              		{
                		current_colors[0]=colors[color_index][0];
                		current_colors[1]=colors[color_index][1];
                		current_colors[2]=colors[color_index][2];
              		}
              		if (selected)
              		{
                		current_colors[0]=colors[color_index][0]*.5;
                		current_colors[1]=colors[color_index][1]*.5;
                		current_colors[2]=colors[color_index][2]*.5;
             		}
             		glcolor(current_colors);

			 		quad( // bottom
                  		convert_x(-2),convert_y(currentY),0,
                  		convert_x(voicenameDx),convert_y(currentY),0,
				  		convert_x(voicenameDx-2),convert_y(currentY+2),dz,
				  		convert_x(0),convert_y(currentY+2),dz
					);
			 		quad( // left
                  		convert_x(-2),convert_y(currentY),0,
                  		convert_x(-2),convert_y(currentY+dy),0,
				  		convert_x(0),convert_y(currentY+dy-2),dz,
				  		convert_x(0),convert_y(currentY+2),dz
					);
			 		quad( // up
                  		convert_x(-2),convert_y(currentY+dy+spaceDy),0,
                  		convert_x(voicenameDx),convert_y(currentY+dy+spaceDy),0,
				  		convert_x(voicenameDx-2),convert_y(currentY+dy-2+spaceDy),dz,
				  		convert_x(0),convert_y(currentY+dy-2+spaceDy),dz
					);
				
			 		quad( // right
                  		convert_x(voicenameDx),convert_y(currentY),0,
                  		convert_x(voicenameDx),convert_y(currentY+dy),0,
				  		convert_x(voicenameDx-2),convert_y(currentY+dy-2),dz,
				  		convert_x(voicenameDx-2),convert_y(currentY+2),dz
					);
					quad( // top
                  		convert_x(0),convert_y(currentY+2),dz,
                  		convert_x(0),convert_y(currentY+dy-2+spaceDy),dz,
				  		convert_x(voicenameDx-2),convert_y(currentY+dy-2+spaceDy),dz,
				  		convert_x(voicenameDx-2),convert_y(currentY+2),dz
					);

   					gldisable("lighting");
     	     		if (mididevice)
        	  		{
        	      		font("Sans Serif");
              	  		fontsize(12);  
                
              	  		if (selected)
                    		glcolor(1,1,1);
                  		else
                 			glcolor(0,0,0);

              		}
              		else
              		{
	            		font("Times Roman");
                		fontsize(12);      
           
               			if (selected)
                			glcolor(.5,1,1);
              			else
                			glcolor(.5,0,0);

             		}
              		textalign("left","center");
              		moveto(convert_x(5),convert_y(dy/2+.5+currentY));
              		text(name);
   				    glenable("lighting");
 
			 		// program name

   					gllightmodel();       
     				gllight(0,"position",xlight,ylight,zlight,alight);
            		glcolor(current_colors);
 			 		quad( // bottom
                  		convert_x(voicenameDx),convert_y(currentY),0,
                  		convert_x(width+2),convert_y(currentY),0,
				  		convert_x(width),convert_y(currentY+2),dz,
				  		convert_x(voicenameDx+2),convert_y(currentY+2),dz
					);
			 		quad( // left
                  		convert_x(voicenameDx),convert_y(currentY),0,
                  		convert_x(voicenameDx),convert_y(currentY+dy),0,
				  		convert_x(voicenameDx+2),convert_y(currentY+dy-2),dz,
				  		convert_x(voicenameDx+2),convert_y(currentY+2),dz
					);
			 		quad( // up
                  		convert_x(voicenameDx),convert_y(currentY+dy+spaceDy),0,
                  		convert_x(width+2),convert_y(currentY+dy+spaceDy),0,
				  		convert_x(width),convert_y(currentY+dy-2+spaceDy),dz,
				  		convert_x(voicenameDx+2),convert_y(currentY+dy-2+spaceDy),dz
					);
			 		quad( // right
                  		convert_x(width+2),convert_y(currentY),0,
                  		convert_x(width+2),convert_y(currentY+dy),0,
				  		convert_x(width),convert_y(currentY+dy-2),dz,
				  		convert_x(width),convert_y(currentY+2),dz
					);
					quad( // top
                  		convert_x(voicenameDx+2),convert_y(currentY+2),dz,
                  		convert_x(voicenameDx+2),convert_y(currentY+dy-2+spaceDy),dz,
				  		convert_x(width),convert_y(currentY+dy-2+spaceDy),dz,
				  		convert_x(width),convert_y(currentY+2),dz
					);

    				gldisable("lighting");
        			if (selected)
                    	glcolor(1,1,1);
              		else
                    	glcolor(0,0,0);
	          		font("Sans Serif");
              		fontsize(12);                  
              		textalign("left","center");
              		moveto(convert_x(5+voicenameDx),convert_y(dy/2+.5+currentY));
             		text(mode);
  				    glenable("lighting");
				}
			}
        	refresh();
    		needToDraw=false;
			drawtask.interval=50;
			drawtask.repeat(1);
			drawTaskIsScheduled=true;
   		}
   }
   else drawTaskIsScheduled=false;
}

drawtask = new Task(draw,this);
function delayedDraw()
{
	needToDraw=true;
	if (!drawTaskIsScheduled) draw();
}

function onresize(w,h)
{
 	width  = box.rect[2] - box.rect[0];
 	height = box.rect[3] - box.rect[1];
 	x0 = box.rect[0];
 	x1 = box.rect[1];
 	dy = height/maxVoices;
    aspect = width/height;
    delayedDraw();
}

function updateSelected()
{
			for (var i=0;i<maxVoices;i++)
			{
				voices[i][1]=false; // selected
			}
			for (var i=0;i<selectionArray.length;i++)
			{
				voices[selectionArray[i]][1]=true; // selected
			}
}

function ondrag(x,y,but,cmd,shift,capslock,option,ctrl)
{
	if ((selectionArray.length>0)&&!justClicked)
	{
 		
    	dragIndex = Math.floor(y/dy+0.5);
		if (dragIndex>=voices.length) dragIndex=voices.length-1;
		if (dragIndex<0) dragIndex=0;
		if (dragIndex!=oldDragIndex)
		{
			if (oldDragIndex>=0) 
			{
				dragging=true;
			}
			oldDragIndex = dragIndex;
		}
		delayedDraw();
	}
}

function onclick(x,y,but,cmd,shift,capslock,option,ctrl)
{
	if (selectionArray.length==0) justClicked=true;
    idleIndex = Math.floor(y/dy);
    oldIdleIndex=-1000;
    oldDragIndex=-1000;
	if (!voices[idleIndex][5]) // hidden
	{
		if (shift)
		{
			dragging = false;
			selectionArray = new Array();
			if (selectionStart<0) 
			{
				selectionStart=idleIndex;
				selectionEnd  =idleIndex;
				selectionArray.push(idleIndex);
			}
			else
			{
				selectionEnd  =idleIndex;
				if (selectionEnd<selectionStart)
				{
					var i=selectionStart;
					selectionStart=selectionEnd;
					selectionEnd=i;
				}
				for (var i=selectionStart;i<=selectionEnd;i++)
				{
					selectionArray.push(i);
				}
			}
			updateSelected();
		}
		else if (cmd)
		{
			dragging = false;
			var alreadySelected=false;
			for (var i=0;i<selectionArray.length;i++)
			{
				if (selectionArray[i]==idleIndex)  // selected
				{
					selectionArray.splice(i,1);
					alreadySelected=true;
				}
			}
			if (!alreadySelected)
			{
				selectionArray.push(idleIndex);
			}
			updateSelected();
		}
		else if (selectionArray.length==0)
		{
			dragging = false;
			for (var i=0;i<maxVoices;i++)
			{
				voices[i][1]=false; // selected
			}
 			selectionArray = new Array();
  			selectionStart=-1;
			selectionEnd  =-1;
    		eplayer = top_patcher.getnamed("core").subpatcher().getnamed("audio");
    		if (x<voicenameDx)
    			eplayer.message("edit_voice_name",idleIndex);
			else
       			eplayer.message("open_program_editor",idleIndex);
		}
		delayedDraw();
	}
}

function mouseUp()
{
	if (dragging)
	{
		dragging     = false;
		oldDragIndex = -1000;
		selectionArray.push(dragIndex); // in this case, idleIndex is the index where to drag
   		eplayer = top_patcher.getnamed("core").subpatcher().getnamed("audio");
   		eplayer.message("move_voices_to",selectionArray);
 	}
	justClicked=false;
}
	
function mousestate(lx,ly)
{
	mouseX=lx-x0;
	idleIndex=Math.floor((ly-y0)/dy);
	if (idleIndex!=oldIdleIndex) 
	{
		delayedDraw();
		oldIdleIndex = idleIndex;
	}
}

delayedDraw();
