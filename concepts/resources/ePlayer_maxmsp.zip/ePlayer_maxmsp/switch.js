var width = box.rect[2] - box.rect[0];
var height = box.rect[3] - box.rect[1];
var aspect = width/height;
var vbrgb = [jsarguments[1],jsarguments[2],jsarguments[3],1];
var onstate=false;
var idlestate = false;

inlets = 1;
outlets = 1;
sketch.default2d();

function draw_on ()
{
       with (sketch) {
            glclearcolor(vbrgb);
             glclear();  
             moveto(0,0);
            if (idlestate)
                 glcolor(0,0,0,1);
            else
                  glcolor(0.3,0.3,0.3,1);
           circle(1);
             glcolor(1,0,0,1);
            circle(0.7);
             glcolor(0,0,0,1);
            if (idlestate)
                 glcolor(0,0,0,1);
            else
                  glcolor(0.3,0.3,0.3,1);
                 moveto(0,0.25);
                 circle(0.25,0,180);                        
                 moveto(0,-0.25);
                 circle(0.25,180,360);                        
                 moveto(0,0);
                plane(.25,.25);
 
            refresh();
        }
}

function on ()
{
    outlet(0,"reverb_state",1);
    draw_on();
}

function draw_off()
{
       with (sketch) {
            glclearcolor(vbrgb);
             glclear();  
             moveto(0,0);
            if (idlestate)
                 glcolor(0,0,0,1);
            else
                  glcolor(0.3,0.3,0.3,1);
             circle(1);
             glcolor(1,1,1,1);
            circle(0.7);
            refresh();
        }
}

function off ()
{
    outlet(0,"reverb_state",0);
    draw_off();
}

function init (ldir)
{
    draw_off();
}

function onidle (x, y, button, mod1, shift, caps, opt, mod2)
{
    idlestate = true;
    if (onstate) 
        draw_on();
    else
        draw_off();
}

function onidleout (x, y, button, mod1, shift, caps, opt, mod2)
{
    idlestate = false;
     if (onstate) 
        draw_on();
    else
        draw_off();
}
function onclick (x, y)
{
    idlestate = true;
    onstate=!onstate;
    if (onstate) 
    {
        draw_on();
        outlet(0,"reverb_state",1);
    }
    else
    {
        draw_off(true);
        outlet(0,"reverb_state",0);
    }
}

init();

function set (lswitch)
{
    if (lswitch==1)
     {
        onstate = true;
        draw_on();
    }
    else
    {
        onstate = false;
        draw_off();
    }
}

