var mididevice_count = 0;
var mainpatcher;
function directory (ldir)
{
	var thispatcher = this.patcher;
    var audio_object = thispatcher.newdefault(420,120,"contimbre_eplayer~", number_of_audio_outputs);
        audio_object.varname = "audio";

		thispatcher.connect(thispatcher.getnamed("raudio"), 0, audio_object, 0);
		for (var i=0;i<number_of_audio_outputs;i++)
		{
    		thispatcher.connect(audio_object,i,thispatcher.getnamed("s"+(i+1)),0);
		}
	audio_object.message("directory",ldir);
}

function new_midi_device(lstring)
{
  mainpatcher = this.patcher.newdefault(20, 300+mididevice_count*18,"eplayer_midiin");
  mainpatcher.subpatcher().getnamed("midiin").message("port"  ,lstring);
  mainpatcher.subpatcher().getnamed("midimanager").message("device",lstring);
  mididevice_count++;
}

