sketch.ortho3d(); //like default3d but uses orthographic projection

var my_number=0;
var val                       = 0                     ;
var vbrgb                     = [0.999, 0.9, 0.968438];
var vfrgb_idle                = [.9 , 0.9, 0.9,1.]    ;
var vfrgb                     = [0.8,0.8,0.8,1.]      ;
var vfrgb_idle_solo           = [.9 , 0.9, 0.5,1.]    ;
var vfrgb_solo                = [0.8,0.8,0.0,1.]      ;
var vfrgb_idle_mute           = [0.85,0.70,0.60]      ;
var vfrgb_mute                = [0.74,0.50,0.46]      ;
var vfrgb_implicite_mute      = [0.79,0.64,0.64]      ;
var vfrgb_idle_implicite_mute = [0.89,0.84,0.80]      ;
var width                     = box.rect[2]-box.rect[0];
var height                    = box.rect[3]-box.rect[1];
var roundness                 = 0.5                    ;
var solo           =false;
var implicite_mute =false;
var mute           =false;
var old_is_mute    =false;
var current_is_mute=false;  //mouse is over the mute part
var master_mxj;
var is_idle        =false;

function getcolor(type)
{
    if ((type=="solo")&&solo)
    {
        if (is_idle&&!current_is_mute)
        {
            return(vfrgb_idle_solo);
        }
        else
        {
            return(vfrgb_solo);
        }
    }
    if ((type=="mute")&&mute)
    {
        if (is_idle&&current_is_mute)
        {
            return(vfrgb_idle_mute);
        }
        else
        {
            return(vfrgb_mute);
        }
    }
    if ((type=="mute")&&implicite_mute)
    {
        if (is_idle&&current_is_mute)
        {
            return(vfrgb_idle_implicite_mute);
        }
        else
        {
            return(vfrgb_implicite_mute);
        }
    }
    if (((is_idle)&&(type=="mute")&&current_is_mute)
        ||
        ((is_idle)&&(type=="solo")&&(!current_is_mute))
       )
    {
        return(vfrgb_idle);
    }
    else
    {
        return(vfrgb);
    }
}

function draw(lylight)
{
    var cylinderwidth = 0.5*width - roundness*height/1;
    var aspect = 2*cylinderwidth/height;
    var ncylinderwidth = width - roundness*height/1;
    var naspect = ncylinderwidth/height;
    var halfspheredx = roundness*2/1;

    with (sketch) {
        glclearcolor(vbrgb);
        glclear();  
        glloadidentity();          
        glscale(roundness,1,1);
        // gllight(0,"position",0,.5,1,0.0);
        shapeorient(0,90,90);    
        glcolor(getcolor("solo"));
        moveto  (-aspect-halfspheredx,0,0);
        cylinder(.9,.9,aspect);      
        // gllight(0,"position",0,.5,1,0.0);
        glcolor(getcolor("mute"));
        moveto  (aspect+halfspheredx,0,0);
        cylinder(.9,.9,aspect);  

        // gllight(0,"position",0,.5,1,0.0);
        glcolor(getcolor("solo"));
        moveto(-halfspheredx,0,0);
        shapeorient(0,90,0);    
        sphere(.9,0,360,0,90);   
        // gllight(0,"position",0,.5,1,0.0);
        glcolor(getcolor("mute"));
        moveto( halfspheredx,0,0);
        shapeorient(0,-90,0);    
        sphere(.9,0,360,0,90);   
        // gllight(0,"position",0,.5,1,0.0);
        glcolor(getcolor("solo"));
        shapeorient(0,-90,0);   
        moveto(-naspect/roundness,0,0);
        sphere(.9,0,360,0,90);  
        // gllight(0,"position",0,.5,1,0.0);
        glcolor(getcolor("mute"));
        shapeorient(0,90,0);    
        moveto(naspect/roundness,0,0);
        sphere(.9,0,360,0,90);   

        font("Sans Serif");                  
        fontsize(12);                  
        textalign("center","center");        
        glcolor(0,0,0);
        moveto(-aspect-halfspheredx,0,0);
        text("S");
        moveto(aspect+halfspheredx,0,0);
        text("M");
    }
}

function redraw_idle()
{
    draw(.5);
    refresh();
}

function onclick()
{
        var owner; 
    var top_patcher= this.patcher;
    owner = this.patcher.parentpatcher; 
    while (owner) { 
        top_patcher = owner; 
        owner = owner.parentpatcher; 
    } 
    master_mxj = top_patcher.getnamed("core").subpatcher().getnamed("audio");
    if (current_is_mute)
    {
        mute=!mute;
        if (mute) solo=false;
    }
    else
    {
         solo = !solo;
         if (solo) mute=false;
    }
    if (current_is_mute)
    {
        if (mute)
            master_mxj.message("mute",my_number,1);
        else
            master_mxj.message("mute",my_number,0);
    }
    else
    {
        if (solo)
            master_mxj.message("solo",my_number,1);
        else
            master_mxj.message("solo",my_number,0);
    }

    draw(0);
    refresh();
    delay_redraw_task=new Task(redraw_idle,this);
    delay_redraw_task.schedule(150);
}

function onidle(x,y,but,cmd,shift,capslock,option,ctrl)
{
    is_idle = true;
    current_is_mute = (x>=(width/2));
    old_is_mute = current_is_mute;
    draw(.5);
    refresh();
}

function onidleout()
{
    is_idle = false;
    draw(.5);
    refresh();
}

function set_number(lnum)
{
    my_number = lnum;

    redraw_idle();
    delay_redraw_task=new Task(redraw_idle,this);
    delay_redraw_task.schedule(150);
}

function set_solo(lsolo)
{
    if (lsolo==0)
        solo=false;
    else
        solo=true ;
}

function set_mute(lmute)
{
    if (lmute==0)
        mute=false;
    else
        mute=true ;
}

function set_implicite_mute(onoff)
{
    if ((onoff==1)&&!solo)
        implicite_mute=true ;
    else
        implicite_mute=false;
}

function redraw()
{
    draw(.5);
    refresh();
}
redraw();

