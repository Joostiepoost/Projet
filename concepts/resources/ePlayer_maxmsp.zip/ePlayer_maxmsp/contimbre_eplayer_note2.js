var top_patcher;

var is_idle = false;
var idle_on_flag = true;
var my_number;
var master;
var width = box.rect[2] - box.rect[0];
var height = box.rect[3] - box.rect[1];
var aspect = width/height;

function no_idle ()
{
  idle_on_flag = false;
}

function ok_idle ()
{
  idle_on_flag = true;
}

function init ()
{
  my_number = jsarguments[1];
    var owner; 
    owner = this.patcher.parentpatcher; 
    while (owner) { 
        top_patcher = owner; 
        owner = owner.parentpatcher; 
    } 
    master = top_patcher.getnamed("core").subpatcher().getnamed("audio");
}

function onclick (x, y)
{
      if(x<(width*.75))
      {
        if(x<(width*.5))
        {
            master.message("start_note_editor_menu");
        }
        else
        {
            master.message("start_note_editor",x,-0.25);
        }
      }
      else
      {
            master.message("start_note_editor",x,-10);
      }
}

function onidle (x, y, button, mod1, shift, caps, opt, mod2)
{
  if (!is_idle && idle_on_flag) {
    master.message("note_graphic_idle",my_number);
    is_idle = true;
  }
}

function onidleout (x, y, button, mod1, shift, caps, opt, mod2)
{
    master.message("note_graphic_idle_out",my_number);
    is_idle = false;
}
