var top_patcher;
var master;
var number_of_audio_outputs = 32;

function directory (ldir)
{
    var owner; 
    owner = this.patcher.parentpatcher; 
    while (owner) { 
        top_patcher = owner; 
        owner = owner.parentpatcher; 
    } 
	var manage_patcher = top_patcher.getnamed("core").subpatcher();
    var audio_object = manage_patcher.newdefault(420,120,"contimbre_eplayer~", number_of_audio_outputs);
        audio_object.varname = "audio";

		manage_patcher.connect(manage_patcher.getnamed("raudio"), 0, audio_object, 0);
		for (var i=0;i<number_of_audio_outputs;i++)
		{
    		manage_patcher.connect(audio_object,i,manage_patcher.getnamed("s"+(i+1)),0);
		}
	audio_object.message("directory",ldir);
}
