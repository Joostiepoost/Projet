outlets=2;
sketch.default2d();
    var aspect;
    var width;
    var height;
    var shrink = .98;
    var images = new Array(9);
    var oldpitch = -1;
    var number_of_octaves = 11;
    var keyboard_length = 12*number_of_octaves;
    var colors = new Array(
                            new Array(1,1,1), //white
                            new Array(.91,.91,.91), //not highlighted2
                            new Array(.8,.95,.8), //highlighted1
                            new Array(.4,.95,.2) //clickhighlightes
                       );
    var pitch_selected = new Array(keyboard_length);
    var fullmenutexts  = new Array(keyboard_length);
    var menutexts      = new Array(keyboard_length);
    var max_text_length = 0;
    var show_full_text = this.patcher.getnamed("fullname");
    show_full_text.hidden=true;
    var textrect = new Array(4);
    for (var i=0;i<keyboard_length;i++)
    {
        pitch_selected[i]=false;
        menutexts[i]="";
    }
    black_keylist = new Array(0,1,0,1,0,0,1,0,1,0,1,0);

function setidle(pitch)
{
    if ((pitch>=0)&&(pitch<128))
    {
        if (oldpitch!=pitch)
        {            
           draw_note_menu_item(oldpitch,0);
           pitch_selected[oldpitch]=false;
           oldpitch=pitch;
           draw_note_menu_item(pitch,2);
           pitch_selected[pitch]=true;
           refresh();
        }
    }
    else
    {
        setidleout();
    }
}

function onidle(x,y,but,cmd,shift,capslock,option,ctrl)
{
    var pitch = Math.floor((height-y)/height*keyboard_length);
    if ((pitch<128)&&(pitch>=0)&&(fullmenutexts[pitch]!=null)) 
    {
        if (fullmenutexts[pitch].length>menutexts[pitch].length)
        {
          textrect[0]=x;
          textrect[1]=y+20;
          textrect[2]=x+200;
          textrect[3]=y+200;
          show_full_text.rect=textrect;
          show_full_text.message("set",fullmenutexts[pitch]);
          outlet(0,"setidle",pitch);
          show_full_text.hidden=false;
        }
        else
          show_full_text.hidden=true;
        setidle(pitch);
    }
}

function oldpitch_off()
{
     draw_note_menu_item(oldpitch,0);
     pitch_selected[oldpitch]=false;
     oldpitch=-1;
     refresh();
}

function setidleout()
{
    oldpitch_off();
 }

function onidleout(x,y,but,cmd,shift,capslock,option,ctrl)
{
    oldpitch_off();
    outlet(0,"setidleout");
    show_full_text.hidden=true;
}

function keyoff(pitch)
{
    if (pitch_selected[pitch])
    {
      draw_note_menu_item(pitch,2);
    }
    else
    {
      draw_note_menu_item(pitch,0);
    }
    refresh();
 }

function noteon(pitch)
{
    if ((pitch>=0)&&(pitch<128))
    {
      draw_note_menu_item(pitch,3);
      refresh();
      var delay_message_task=new Task(keyoff,this,pitch);
      delay_message_task.schedule(60);
    }
}


function onclick(x,y,but,cmd,shift,capslock,option,ctrl)
{
    var pitch = Math.floor((height-y)/height*keyboard_length);
    noteon(pitch);
    outlet(0,"noteon",pitch);
    outlet(1,"test_noteon",pitch);
}


draw();

function draw_note_menu_item (lpitch,lcolorindex)
{
    if ((lpitch>=0)&&(lpitch<128))
    {
        var lcolorindex1 = lcolorindex;
        if (lcolorindex == 0)
            lcolorindex1 = black_keylist[lpitch%12];
        var ly = lpitch/keyboard_length;
        var ldy = 1/keyboard_length;
        ly1 = ly*2-1;
        ly2 = (ly+ldy)*2-1;
        var lx1 = -1*aspect;
        var lx2 = 1*aspect;
        with (sketch) {
          glcolor(colors[lcolorindex1]);
          gllinewidth(1.);
          quad(lx1,ly1,0,lx1,ly2,0,lx2,ly2,0,lx2,ly1,0);
          glcolor(0.,0.,0.);
          framequad(lx1,ly1,0,lx1,ly2,0,lx2,ly2,0,lx2,ly1,0);
           gllinewidth(3);
           glcolor(0,0,0);
           for (var i=0;i<number_of_octaves;i++)
           {
              moveto(-1*aspect,(i/number_of_octaves*2-1),0);
              line(aspect*2,0,0);
           }
           glcolor(1,0,0);
           gllinewidth(4);
           moveto(-1*aspect,(5/number_of_octaves*2-1),0);
           line(aspect*2,0,0);

            font("Sans Serif"); 
            var tfontsize = 12;
            if (max_text_length>84) tfontsize = tfontsize*84/max_text_length;
            fontsize(tfontsize);                  
            textalign("left","center");        
            glcolor(0,0,0);
            moveto(-.98*aspect,(ly1+ly2)/2,0);
            text(menutexts[lpitch]);
        }
    }
}

function text(lpitch,menutext,fullmenutext)
{
        menutexts    [lpitch]=    menutext;
        fullmenutexts[lpitch]=fullmenutext;
        draw_note_menu_item(lpitch,0);
       refresh();
}

function draw()
{
    width = box.rect[2] - box.rect[0];
    height = box.rect[3] - box.rect[1];
    aspect = width/height;
    shrink = 1;
 
    with (sketch) {
       glclearcolor(.5,.6,.9);
       glclear();   


        max_text_length = 0;

       for (var i=0;i<128;i++)
       {
         if (menutexts[i].length>max_text_length)
         {
            max_text_length = menutexts[i].length;
         }
       }

       for (var i=0;i<128;i++)
       {
         draw_note_menu_item(i,0);
       }
       refresh();
    }         
}


function onresize()
{
    draw();
}
