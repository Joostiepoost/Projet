sketch.ortho3d(); //like default3d but uses orthographic projection
var val = 0;
var vbrgb = [jsarguments[7],jsarguments[8],jsarguments[9],0];
var vfrgb_idle = [jsarguments[4],jsarguments[5],jsarguments[6],1.];
var vfrgb = [jsarguments[1],jsarguments[2],jsarguments[3],1.];
var dtext="";

draw(vfrgb,10);

function set()
{
  dtext = arguments[0];
  for (var i=1;i<arguments.length;i++)
  {
    dtext = dtext+" "+arguments[i];
  }
  draw(vfrgb,10);
  refresh();
}

function onidle()
{
  draw(vfrgb_idle,10);
  refresh();
}

function onidleout()
{
  draw(vfrgb,10);
  refresh();
}


function redraw_idleout()
{
  draw(vfrgb,10);
  refresh();
}

function onclick()
{
  outlet(0,"bang");
  draw(vfrgb,-10);
  refresh();
  delay_redraw_task=new Task(redraw_idleout,this);
  delay_redraw_task.schedule(150);
}

function draw(lcolor,lylight)
{
    var theta;
    var width = box.rect[2] - box.rect[0];
    var height = box.rect[3] - box.rect[1];
    var roundness = 0.5;
    var cylinderwidth = width - roundness*height;
    var aspect = cylinderwidth/height;

        with (sketch) {
            glclearcolor(vbrgb);
            glclear();  
            glloadidentity();          
            glcolor(lcolor);
           // gllight(0,"position",0,lylight*aspect,20*aspect,8.5);
           shapeorient(0,90,90);    
               moveto(0,0,0);
           cylinder(1,1,aspect);      
            font("Sans Serif");                  
            fontsize(9);                  
             textalign("center","center");        
             moveto(0,0.1,0);
             glcolor(0,0,0);
             text(dtext);
                moveto(aspect/roundness,0,0);
            glcolor(lcolor);
            glscale(roundness,1,1);
           shapeorient(0,90,0);    
             sphere(1,0,360,0,90);                        
            moveto(-aspect/roundness,0,0);
           shapeorient(0,-90,0);   
            sphere(1,0,360,0,90);                        
       }
}

function onresize(w,h)
{
    draw(vfrgb);
    refresh();
}
