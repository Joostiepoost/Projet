sketch.ortho3d(); //like default3d but uses orthographic projection
var val = 0;
var vbrgb = [jsarguments[1],jsarguments[2],jsarguments[3],0];
var top_patcher=this.patcher;
var mono_sfrecord_box;
var mono_open_box;
var mono_onoff_box;
var stereo_sfrecord_box;
var stereo_open_box;
var stereo_onoff_box;
var octo_sfrecord_box;
var octo_open_box;
var octo_onoff_box;
var octo2_sfrecord_box;
var octo2_open_box;
var octo2_onoff_box;
var octo3_sfrecord_box;
var octo3_open_box;
var octo3_onoff_box;
var octo4_sfrecord_box;
var octo4_open_box;
var octo4_onoff_box;
var octo_metro_box;
var stereo_metro_box;
var mono_metro_box;
var save_dialog_box;
var mute_box;
var record_channels_box;
var channel_modev=0;
var startrec_animation_counter=0;
var startrec_animation_counter_direction=true;
var idle_state=false;
var thisbox;
var vfrgb=new Array(3);

var rgb = [
  [0.74,0.8,0.12],
  [0.91,0.65,0.6 ],
  [0.91,0.35,0.35 ]
];

var rgb_idle = [
  [0.84,0.8,0.32],
  [0.96,0.70,0.65],
  [0.96,0.50,0.5]
];

var norecord_rgb = [0.74,0.8,0.12];
var norecord_idle_rgb = [0.84,0.8,0.32];
var ready_to_record_rgb = [0.91,0.65,0.6 ];
var ready_to_record_idle_rgb = [0.96,0.70,0.65];
var record_rgb        = [0.91,0.45,0.4 ];
var record_idle_rgb = [0.96,0.50,0.45];
var record_state = 0;  //0="no",1= "ready",2= "yes"


function getrgb(lrgb)
{
    vfrgb[0] = lrgb[record_state][0];
    vfrgb[1] = lrgb[record_state][1];
    vfrgb[2] = lrgb[record_state][2];
}

getrgb(rgb);

var textsv=["Record","Start Rec",""];
var textv = "";

function draw(lylight)
{
     var theta;
    var width = box.rect[2] - box.rect[0];
    var height = box.rect[3] - box.rect[1];
    var roundness = 0.5;
    var cylinderwidth = width - roundness*height;
    var aspect = cylinderwidth/height;

        with (sketch) {
            glclearcolor(vbrgb);
            glclear();  
            glloadidentity();          
            glcolor(vfrgb);
           // gllight(0,"position",0,lylight*aspect,20*aspect,8.5);
           shapeorient(0,90,90);    
               moveto(0,0,0);
           cylinder(1,1,aspect);      
            font("Sans Serif");                  
            fontsize(12);                  
             textalign("center","center");
             moveto(0,0.1,0);
             glcolor(0,0,0);
             text(textv);
                moveto(aspect/roundness,0,0);
            glcolor(vfrgb);
            glscale(roundness,1,1);
           shapeorient(0,90,0);    
             sphere(1,0,360,0,90);                        
            moveto(-aspect/roundness,0,0);
           shapeorient(0,-90,0);   
            sphere(1,0,360,0,90);                        
       }
}

function drawtime(lylight)
{
    var theta;
    var width = box.rect[2] - box.rect[0];
    var height = box.rect[3] - box.rect[1];
    var roundness = 0.5;
    var cylinderwidth = width - roundness*height;
    var aspect = cylinderwidth/height;

        with (sketch) {
            glclearcolor(vbrgb);
            glclear();  
            glloadidentity();          
            glcolor(vfrgb);
            gllight(0,"position",0,lylight*aspect,20*aspect,8.5);
            shapeorient(0,90,90);    
            moveto(0,0,0);
            cylinder(1,1,aspect);      
            font("Sans Serif");
            
            fontsize(10);                  
            textalign("center","center");
            moveto(0,0.1,0);
            glcolor(0,0,0);
            text(textv);
            moveto(aspect/roundness,0,0);
            glcolor(vfrgb);
            glscale(roundness,1,1);
            shapeorient(0,90,0);    
            sphere(1,0,360,0,90);                        
            moveto(-aspect/roundness,0,0);
            shapeorient(0,-90,0);   
            sphere(1,0,360,0,90);                        
       }
}

function record_text()
{
  textsv[0] = arguments[0];
  for (var i=1;i<arguments.length;i++)
  {
    textsv[0] = textsv[0]+" "+arguments[i];
  }
}

function startrec_text()
{
  textsv[1] = arguments[0];
  for (var i=1;i<arguments.length;i++)
  {
    textsv[1] = textsv[1]+" "+arguments[i];
  }
}

function recordtime(ltime)
{
    ltime = Math.floor(ltime);
    var milliseconds = ltime%10;
    ltime = Math.floor(ltime/10);
    var milliseconds10 = ltime%10;
    ltime = Math.floor(ltime/10);
    var milliseconds100 = ltime%10;
    ltime = Math.floor(ltime/10);
    var seconds     = ltime %10;
    ltime = Math.floor(ltime/10);
    var seconds10 = ltime %6;
    ltime = Math.floor(ltime/6);
    var minutes = ltime %10;
    ltime = Math.floor(ltime/10);
    var minutes10 = ltime %6;
    ltime = Math.floor(ltime/6);
    var hours = ltime %10;
    ltime = Math.floor(ltime/10);
    var hours10 = ltime %10;
    textv = hours10+""+hours+":"+minutes10+""+minutes+":"+seconds10+""+seconds+"."+milliseconds100+""+milliseconds10+""+milliseconds;
  drawtime(10);
  refresh();
}

function stopall()
{
  getrgb(rgb_idle);

  textv = textsv[0];
  draw(10);
  refresh();
      mono_onoff_box  .message(0);
      stereo_onoff_box.message(0);
      octo_onoff_box  .message(0);
      octo2_onoff_box .message(0);
      octo3_onoff_box .message(0);
      octo4_onoff_box .message(0);
      record_channels_box.message("ignoreclick",0);
      thisbox.message            ("ignoreclick",0);
}

var stopall_task = new Task(stopall,this);

function stop_recording ()
{
      mute_box .message(1);
      octo_metro_box.message  (0);
      stereo_metro_box.message(0);
      mono_metro_box.message  (0);
      thisbox.message            ("ignoreclick",1);
      record_channels_box.message("ignoreclick",1);
      record_channels_box.message("set_record_state",0);
      stopall_task.schedule(300);
}

function startrec_animation()
{
  var fraction = startrec_animation_counter*0.1;
  record_channels_box.message("animation",fraction);
  var oneminusfraction = 1-fraction;
  if (idle_state)
  {
    vfrgb[0] = 1*oneminusfraction+ready_to_record_idle_rgb[0]*fraction;
    vfrgb[1] = 0.3*oneminusfraction+ready_to_record_idle_rgb[1]*fraction;
    vfrgb[2] = 0.3*oneminusfraction+ready_to_record_idle_rgb[2]*fraction;
  }
  else
  {
    vfrgb[0] = 1*oneminusfraction+ready_to_record_rgb[0]*fraction;
    vfrgb[1] = 0*oneminusfraction+ready_to_record_rgb[1]*fraction;
    vfrgb[2] = 0*oneminusfraction+ready_to_record_rgb[2]*fraction;
  }

  draw(10);
  refresh();

  if (startrec_animation_counter_direction)
  {
    startrec_animation_counter++;
    if (startrec_animation_counter==10)
      startrec_animation_counter_direction=false;
  }
  else
  {
    startrec_animation_counter--;
    if (startrec_animation_counter==0)
      startrec_animation_counter_direction=true;
  }
}

var startrec_animation_task = new Task(startrec_animation,this);

function init()
{
    var owner; 
    owner = this.patcher.parentpatcher; 
    while (owner) { 
        top_patcher = owner; 
        owner = owner.parentpatcher; 
    } 
  var record_patcher = top_patcher.getnamed("manage").subpatcher().getnamed("record").subpatcher();
  save_dialog_box     = record_patcher.getnamed("record").subpatcher().getnamed("savedialog"   );
  
  mono_sfrecord_box   = record_patcher.getnamed("record").subpatcher().getnamed("mono_record"  );
  mono_onoff_box      = record_patcher.getnamed("record").subpatcher().getnamed("mono_onoff"   );
  mono_open_box       = record_patcher.getnamed("record").subpatcher().getnamed("mono_open"    );
  
  stereo_sfrecord_box = record_patcher.getnamed("record").subpatcher().getnamed("stereo_record");
  stereo_onoff_box    = record_patcher.getnamed("record").subpatcher().getnamed("stereo_onoff" );
  stereo_open_box     = record_patcher.getnamed("record").subpatcher().getnamed("stereo_open"  );
  octo_sfrecord_box   = record_patcher.getnamed("record").subpatcher().getnamed("octo_record"  );
  octo_open_box       = record_patcher.getnamed("record").subpatcher().getnamed("octo_open"    );
  octo_onoff_box      = record_patcher.getnamed("record").subpatcher().getnamed("octo_onoff"   );
  octo2_sfrecord_box  = record_patcher.getnamed("record").subpatcher().getnamed("octo2_record" );
  octo2_open_box      = record_patcher.getnamed("record").subpatcher().getnamed("octo2_open"   );
  octo2_onoff_box     = record_patcher.getnamed("record").subpatcher().getnamed("octo2_onoff"  );
  octo3_sfrecord_box  = record_patcher.getnamed("record").subpatcher().getnamed("octo3_record" );
  octo3_open_box      = record_patcher.getnamed("record").subpatcher().getnamed("octo3_open"   );
  octo3_onoff_box     = record_patcher.getnamed("record").subpatcher().getnamed("octo3_onoff"  );
  octo4_sfrecord_box  = record_patcher.getnamed("record").subpatcher().getnamed("octo4_record" );
  octo4_open_box      = record_patcher.getnamed("record").subpatcher().getnamed("octo4_open"   );
  octo4_onoff_box     = record_patcher.getnamed("record").subpatcher().getnamed("octo4_onoff"  );
  octo_metro_box      = record_patcher.getnamed("record").subpatcher().getnamed("octo_metro"   );
  stereo_metro_box    = record_patcher.getnamed("record").subpatcher().getnamed("stereo_metro" );
  mono_metro_box      = record_patcher.getnamed("record").subpatcher().getnamed("mono_metro"   );

  mute_box = record_patcher.getnamed("mute");
  save_dialog_box.message("name","untitled.aiff");
  mute_box.message(1);
  mono_sfrecord_box.message("samptype","int24");
  stereo_sfrecord_box.message("samptype","int24");
  octo_sfrecord_box.message("samptype","int24");
  octo2_sfrecord_box.message("samptype","int24");
  octo3_sfrecord_box.message("samptype","int24");
  octo4_sfrecord_box.message("samptype","int24");
  record_channels_box = top_patcher.getnamed("record_channels");
  thisbox             = top_patcher.getnamed("record"         );
  record_channels_box.message("ignoreclick",0);
  record_channels_box.message("set_record_state",0);
  record_state = 0;
  stop_recording();
  startrec_animation_task.cancel();
  getrgb(rgb);
  textv = textsv[record_state];
  draw(10);
  refresh();
}

function onidle()
{
  idle_state=true;
  if (record_state!=1)
  {
    getrgb(rgb_idle);
    if (record_state==2)  
      drawtime(10);
    else
    {
      textv = textsv[record_state];
      draw(10);
    }
    refresh();
  }
}

function onidleout()
{
  idle_state=false;
  if (record_state!=1)
  {
    getrgb(rgb);
    if (record_state==2)  
      drawtime(10);
    else
    {
      textv = textsv[record_state];
      draw(10);
    }
    refresh();
  }
}


function redraw_idleout()
{
}

function channel_mode(lindex)
{
  channel_modev = lindex;
}

function onclick()
{
  record_state+=1;
  if (record_state>2)
    record_state = record_state%3;
  switch (record_state) {

    case 0:  //stop recording
      stop_recording();
      break;

    case 1:  //open file
      record_channels_box.message("ignoreclick",1);
      save_dialog_box.message("bang");
      break;

    case 2:  //start recording
      startrec_animation_task.cancel();
      if (channel_modev==3)
        mono_onoff_box.message(1);
      if (channel_modev==0)
        stereo_onoff_box.message(1);
      if (channel_modev==1)
        octo_onoff_box.message(1);
       if (channel_modev==2)
       {
        octo_onoff_box.message (1);
        octo2_onoff_box.message(1);
        octo3_onoff_box.message(1);
        octo4_onoff_box.message(1);
      }
      record_channels_box.message("ignoreclick",1);
      record_channels_box.message("set_record_state",2);
      getrgb(rgb_idle);
      textv = textsv[record_state];
      draw(10);
      refresh();
      break;
  }
}

function bang()
{
    onclick();
}

function onresize(w,h)
{
}

function cancel()
{
    record_state=0;
    record_channels_box.message("ignoreclick",0);
    record_channels_box.message("set_record_state",0);
    getrgb(rgb);
    textv = textsv[record_state];
    draw(10);
    refresh();
}

function file()
{
  mute_box.message(0);
  startrec_animation_counter=0;
  startrec_animation_counter_direction=true;
  startrec_animation_task.interval = 50;
  textv = textsv[record_state];
  startrec_animation_task.repeat();
  var lfile = arrayfromargs(arguments);
  var last_dot;
  var last_slash;
  var dot = new Array(1);
  dot[0]=46;
  var end = new Array(97,105,102,102);
  for (last_dot=lfile.length-1;last_dot>=0;last_dot--)
  {
        if (lfile[last_dot]==46) break;
  }
  for (last_slash=lfile.length-1;last_slash>=0;last_slash--)
  {
    if (lfile[last_slash]==47) break;
  }
  if (last_slash<last_dot)
  {
    end   = lfile.slice(last_dot+1);
    lfile = lfile.slice(0,last_dot);
  }
  if (channel_modev==3)
  {
    lfile = lfile.concat (dot  );
    lfile = lfile.concat (end  );
    mono_open_box.message(lfile);
  }
  if (channel_modev==0)
  {
    lfile = lfile.concat (dot  );
    lfile = lfile.concat (end  );
    stereo_open_box.message(lfile);
  }
  if (channel_modev==1)
  {
    lfile = lfile.concat (dot  );
    lfile = lfile.concat (end  );
    octo_open_box.message(lfile);
  }
    if (channel_modev==2)  //32 channels
    {
      var file1 = lfile.concat(new Array(49,46));
      file1 = file1.concat(end);
      var file2 = lfile.concat(new Array(50,46));
      file2 = file2.concat(end);
      var file3 = lfile.concat(new Array(51,46));
      file3 = file3.concat(end);
      var file4 = lfile.concat(new Array(52,46));
      file4 = file4.concat(end);
      octo_open_box.message(file1);
      octo2_open_box.message(file2);
      octo3_open_box.message(file3);
      octo4_open_box.message(file4);
    }
}
