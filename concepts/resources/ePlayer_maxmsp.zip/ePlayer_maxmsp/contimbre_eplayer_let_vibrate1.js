//// let_vibrate.js /////////////
////////started 16.12.2012 /////////////

var top_patcher;

var is_idle = false;
var master;
var width = box.rect[2] - box.rect[0];
var height = box.rect[3] - box.rect[1];
var aspect = width/height;
var let_vibrate = false;
var is_idle = false;

inlets = 1;
outlets = 1;
sketch.default2d();

function set(onoff)
{
   let_vibrate=(onoff!=0);
   draw();
}

function draw()
{
    with (sketch) {
      glclear();  
          
      if (is_idle)
        glcolor(.99,.99,0.7);
      else
      {
        if (let_vibrate)
        {
           glcolor(.99,.99,0.5);
        }
        else
        {
           glcolor(.99,.99,0.9);
        }
      }
      quad(-aspect,-1,0,-aspect,1,0,aspect,1,0,aspect,-1,0);
		beginstroke("basic2d");
        if (let_vibrate)
        {
 		gllinewidth(5);
        }
        else
        {
		gllinewidth(2);
		}
      for (i=0;i<width;i++)
      {
		var fract = i/width;
		var fract1 = i/width - .2;
		if (fract1<0) fract1 = 0;
        var theta = Math.cos(fract*Math.PI*6);
		strokepoint(aspect*(i*2/(width-1)-1),theta*Math.pow(0.05,fract1));
      }
      endstroke();
      refresh();
    }
}

function onclick(x,y,but,cmd,shift,capslock,option,ctrl)
{
    let_vibrate = !let_vibrate;
    if (let_vibrate)
      outlet(0,"let_vibrate_all",1);
    else
      outlet(0,"let_vibrate_all",0);
    draw();
}

function onidle(x,y,but,cmd,shift,capslock,option,ctrl)
{
    is_idle = true;
    draw();
}

function onidleout(x,y,but,cmd,shift,capslock,option,ctrl)
{
    is_idle = false;
    draw();
}

function init()
{
    draw();
}

function onresize(x,y)
{
	width = box.rect[2] - box.rect[0];
	height = box.rect[3] - box.rect[1];
	aspect = width/height;
    draw();
}
draw();