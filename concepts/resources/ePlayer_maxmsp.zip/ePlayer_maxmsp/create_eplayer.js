var mididevice_count = 0;
var number_of_audio_outputs = 32;
var audio_object;
var thispatcher;

function new_midi_device(lstring)
{
  var mainpatcher = this.patcher.getnamed("eplayer_midiins").subpatcher().newdefault(20, 300+mididevice_count*18,"eplayer_midiin");
       mainpatcher.varname = "midimanager"+mididevice_count;
  mainpatcher.subpatcher().getnamed("midiin").message("port"  ,lstring);
  mainpatcher.subpatcher().getnamed("midimanager").message("device",lstring);
  mididevice_count++;
}
