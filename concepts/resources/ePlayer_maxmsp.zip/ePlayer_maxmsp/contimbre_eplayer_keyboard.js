    outlets=2;
    var directory;
    black_keylist = new Array(0,1,0,1,0,0,1,0,1,0,1,0);
    white_chromatic = new Array(0,2,4,5,7,9,11);
    black_chromatic = new Array(1,3,-1,6,8,10,-1);
    black_offset  = new Array(0,0,0,1,0,0,3,0,4,0,5,0);
    white_offset  = new Array(0,0,1,0,2,3,0,4,0,5,0,6);
       var imagesizex =    75;     
       var imagesizey =    150;   
       var imagecopyy =    75;   
    var aspect;
    var width;
    var height;
    var dx0=2;
    var dx1=2;
    var dy1=0;
    var xzone2a;
    var xzone2e;
    var xzone3a;
    var xzone3e;
    var oldpitch = -1;
    var number_of_octaves = 11;
    var whiteblack_yrelation = .555;
    var keyboard_length = 12*number_of_octaves;
    var number_of_white_keys = 7*number_of_octaves;
    var colors = new Array(
                            new Array(1,1,1), //white
                            new Array(.91,.91,.91), //not highlighted2
                            new Array(.8,.95,.8), //highlighted1
                            new Array(.4,.95,.2), //clickhighlightes
                            new Array(0,0,0), //black
                            new Array(.2,.3,.1) //5: blackhighlightes
                       );
    var pitch_selected = new Array(keyboard_length);
    for (var i=0;i<keyboard_length;i++)
    {
        pitch_selected[i]=false;
    }

    var current_color = new Array(number_of_octaves*12);
    for (var i=0;i<current_color.length;i++)
    {
        current_color[i]=0;
    }


function init(ldir)
{
    directory = ldir;
    sketch.default2d();

    draw();
    refresh();
}

function black_key(x,y)
{
    y=height - y;
    var pitch=-1;
     if ((x>xzone2a)&&(x<xzone2e))
      {
        var fdown = (y-dy1)/(height-dy1*2)*number_of_white_keys-.7;
        var down = Math.floor(fdown);
        var within_blackkey = fdown-down;
        var within_octave = down%7;
        var octave = Math.floor(down/7);
        if ((within_blackkey<.6)&&(within_octave>=0)&&(black_chromatic[within_octave]>=0))
        {
            pitch = (black_chromatic[within_octave]+octave*12);
            if ((pitch <0) || (pitch >= 128))
            {
                pitch = -1;
           }
        }
    }
    return pitch;
}


function white_key(x,y)
{
    y=height - y;
    var pitch=-1;
         if ((x>xzone2a)&&(x<xzone3e))
         {
            var down = Math.floor((y-dy1)/(height-dy1*2)*number_of_white_keys);
            var within_octave = down%7;
            var octave = Math.floor(down/7);
            pitch = (white_chromatic[within_octave]+octave*12);
            if (pitch>127) pitch = -1;
        }
    return pitch;
}

function oldpitch_off_then_new(pitch)
{
            draw_black_key(oldpitch,4);
            draw_white_key(oldpitch,0);
            pitch_selected[oldpitch]=false;
            pitch_selected[pitch]=true;
            oldpitch = pitch;
}

function oldpitch_off()
{
            draw_black_key(oldpitch,4);
            draw_white_key(oldpitch,0);
            pitch_selected[oldpitch]=false;
            oldpitch = -1;
              refresh();
}

function setidle(pitch)
{
    if ((pitch>=0)&&(pitch<128))
    {
        if (pitch!=oldpitch)
        {
            oldpitch_off_then_new(pitch);
            draw_black_key(pitch,5);
            draw_white_key(pitch,2);
            refresh();
        }
     }
    else
    {
        setidleout();
    }
}

function setidleout()
{
      oldpitch_off();
}

function onidleout(x,y,but,cmd,shift,capslock,option,ctrl)
{
      setidleout();
}

function onidle(x,y,but,cmd,shift,capslock,option,ctrl)
{
    var pitch = black_key(x,y);
    if (pitch>=0)
    {
        outlet(0,"setidle",pitch);
        if (pitch!=oldpitch)
        {
            oldpitch_off_then_new(pitch);
            draw_black_key(pitch,5);
            refresh();
        }
      }
      else
      {
        pitch = white_key(x,y);
        outlet(0,"setidle",pitch);
         if (pitch>=0)
         {
            if (pitch!=oldpitch)
            {
              oldpitch_off_then_new(pitch);
              draw_white_key(pitch,2);
              refresh();
           }
       }
        else
        {
          oldpitch_off();

        }
      }
    
}

function keyoff(pitch)
{
    if (pitch_selected[pitch])
    {
     draw_white_key(pitch,2);
     draw_black_key(pitch,5);
    }
    else
    {
     draw_white_key(pitch,0);
     draw_black_key(pitch,4);
    }
    refresh();
 }

function noteoff(pitch)
{
       outlet(1,"test_noteoff",pitch,64);
 }

function noteon(pitch)
{
    if ((pitch>=0)&&(pitch<128))
    {
       draw_white_key(pitch,3);
       draw_black_key(pitch,3);
       refresh();
       var delay_message_task=new Task(keyoff,this,pitch);
       delay_message_task.schedule(200);
     }
}

function onclick(x,y,but,cmd,shift,capslock,option,ctrl)
{
    var pitch = black_key(x,y);
    if (pitch<0)
    {
        pitch = white_key(x,y);
    }
    if (pitch>=0)
        {
          noteon(pitch);
          outlet(0,"noteon",pitch);
          outlet(1,"test_noteon",pitch);
        }
}

 


function image(ly,i)
{
}

function draw_white_key (pitch,lcolorindex)
{
  if (black_keylist[pitch%12]==0)
  {
    var within_octave = white_offset[pitch%12]/number_of_white_keys;
    ly = Math.floor(pitch/12)/number_of_octaves+within_octave;
    ldy = 1/number_of_white_keys;
    var ly1 = ly*2-1;
    var ly2 = (ly+ldy)*2-1;
    var lx1 = -1*aspect;
    var lx2 = aspect*((width-imagesizex - dx1)/width*2-1);
    with (sketch) {
       gllinewidth(1);
      glcolor(colors[lcolorindex]);
      quad(lx1,ly1,0,lx1,ly2,0,lx2,ly2,0,lx2,ly1,0);
      glcolor(0.,0.,0.);
      framequad(lx1,ly1,0,lx1,ly2,0,lx2,ly2,0,lx2,ly1,0);
      //thick line at middle c
       glcolor(1,0,0);
      gllinewidth(4);
      moveto(-1*aspect,(5/number_of_octaves*2-1),0);
      line(aspect*2,0,0);
    }
    if (pitch>0)
    {
        draw_black_key(pitch-1,current_color[pitch-1]);
    }
    if (pitch<127)
    {
        draw_black_key(pitch+1,current_color[pitch+1]);
    }
  }
}


function draw_black_key (pitch,lcolorindex)
{
  if (black_keylist[pitch%12]==1)
  {
    current_color[pitch]=lcolorindex;
    var within_octave = black_offset[pitch%12]/number_of_white_keys;
    ldy = 1/number_of_white_keys;
    ly = Math.floor(pitch/12)/number_of_octaves+within_octave;
    var lx1 = -1*aspect;
    var lx2 = aspect*((width-imagesizex - dx1)*whiteblack_yrelation/width*2-1);
    var ly1 = (ly+ldy*.7)*2-1;
    var ly2 = (ly+ldy*1.3)*2-1;
    with (sketch) {
      glcolor(colors[lcolorindex]);
       gllinewidth(1);
      quad(lx1,ly1,0,lx1,ly2,0,lx2,ly2,0,lx2,ly1,0);
      glcolor(0.,0.,0.);
      framequad(lx1,ly1,0,lx1,ly2,0,lx2,ly2,0,lx2,ly1,0);
    }
    }
}


function draw()
{
    width = box.rect[2] - box.rect[0];
    height = box.rect[3] - box.rect[1];
    xzone2a = 0;
    xzone2e = (width-imagesizex-dx1)*whiteblack_yrelation;
    xzone3a = (width-imagesizex-dx1)*whiteblack_yrelation;
    xzone3e = width-imagesizex-dx1;
    aspect = width/height;
    shrink = 1;
 
    with (sketch) {
       glclearcolor(.5,.6,.9);
       glclear();   

     for (var i=1;i<10;i++)
     {
       image(i/11,i-1);
     }
     for (var i=0;i<128;i++)
     {
       gllinewidth(1);
       draw_white_key(i,0);
       draw_black_key(i,4);
       refresh();
     }         
   }         
}


function onresize()
{
    draw();
}
