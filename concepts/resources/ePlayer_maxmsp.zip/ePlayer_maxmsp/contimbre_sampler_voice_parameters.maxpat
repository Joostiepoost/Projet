{
	"patcher" : 	{
		"fileversion" : 1,
		"appversion" : 		{
			"major" : 8,
			"minor" : 0,
			"revision" : 1,
			"architecture" : "x64",
			"modernui" : 1
		}
,
		"classnamespace" : "box",
		"rect" : [ 315.0, 79.0, 860.0, 499.0 ],
		"bglocked" : 0,
		"openinpresentation" : 0,
		"default_fontsize" : 12.0,
		"default_fontface" : 0,
		"default_fontname" : "Arial",
		"gridonopen" : 1,
		"gridsize" : [ 15.0, 15.0 ],
		"gridsnaponopen" : 1,
		"objectsnaponopen" : 1,
		"statusbarvisible" : 2,
		"toolbarvisible" : 1,
		"lefttoolbarpinned" : 0,
		"toptoolbarpinned" : 0,
		"righttoolbarpinned" : 0,
		"bottomtoolbarpinned" : 0,
		"toolbars_unpinned_last_save" : 0,
		"tallnewobj" : 0,
		"boxanimatetime" : 200,
		"enablehscroll" : 1,
		"enablevscroll" : 1,
		"devicewidth" : 0.0,
		"description" : "",
		"digest" : "",
		"tags" : "",
		"style" : "",
		"subpatcher_template" : "",
		"boxes" : [ 			{
				"box" : 				{
					"fontname" : "Arial",
					"fontsize" : 12.0,
					"hidden" : 1,
					"id" : "obj-6",
					"maxclass" : "newobj",
					"numinlets" : 2,
					"numoutlets" : 1,
					"outlettype" : [ "float" ],
					"patching_rect" : [ 99.0, 54.0, 42.0, 22.0 ],
					"text" : "* 0.01"
				}

			}
, 			{
				"box" : 				{
					"fontname" : "Arial",
					"fontsize" : 12.0,
					"hidden" : 1,
					"id" : "obj-17",
					"maxclass" : "newobj",
					"numinlets" : 1,
					"numoutlets" : 1,
					"outlettype" : [ "" ],
					"patching_rect" : [ 99.0, 78.0, 101.0, 22.0 ],
					"text" : "sprintf pan #1 %f"
				}

			}
, 			{
				"box" : 				{
					"bgcolor" : [ 0.827715, 1.0, 0.855871, 1.0 ],
					"hint" : "Pan",
					"id" : "obj-16",
					"knobcolor" : [ 0.2, 0.2, 0.2, 1.0 ],
					"knobshape" : 5,
					"maxclass" : "slider",
					"numinlets" : 1,
					"numoutlets" : 1,
					"outlettype" : [ "" ],
					"parameter_enable" : 0,
					"patching_rect" : [ 103.0, 0.0, 39.0, 22.0 ],
					"size" : 101.0,
					"thickness" : 50.0,
					"varname" : "pan"
				}

			}
, 			{
				"box" : 				{
					"allowdrag" : 0,
					"arrow" : 0,
					"bgcolor" : [ 1.0, 0.921426, 0.785249, 1.0 ],
					"bgfillcolor_angle" : 270.0,
					"bgfillcolor_autogradient" : 0,
					"bgfillcolor_color" : [ 1.0, 0.921426, 0.785249, 1.0 ],
					"bgfillcolor_color1" : [ 0.376471, 0.384314, 0.4, 1.0 ],
					"bgfillcolor_color2" : [ 0.290196, 0.309804, 0.301961, 1.0 ],
					"bgfillcolor_proportion" : 0.39,
					"bgfillcolor_type" : "color",
					"hint" : "Output Channel",
					"id" : "obj-12",
					"items" : [ "1&2", ",", 1, ",", 2, ",", "3&4", ",", 3, ",", 4, ",", "5&6", ",", 5, ",", 6, ",", "7&8", ",", 7, ",", 8, ",", "9&10", ",", 9, ",", 10, ",", "11&12", ",", 11, ",", 12, ",", "13&14", ",", 13, ",", 14, ",", "15&16", ",", 15, ",", 16, ",", "17&18", ",", 17, ",", 18, ",", "19&20", ",", 19, ",", 20, ",", "21&22", ",", 21, ",", 22, ",", "23&24", ",", 23, ",", 24, ",", "25&26", ",", 25, ",", 26, ",", "27&28", ",", 27, ",", 28, ",", "29&30", ",", 29, ",", 30, ",", "31&32", ",", 31, ",", 32 ],
					"maxclass" : "umenu",
					"numinlets" : 1,
					"numoutlets" : 3,
					"outlettype" : [ "int", "", "" ],
					"parameter_enable" : 0,
					"patching_rect" : [ 57.0, 0.0, 46.0, 22.0 ],
					"textcolor" : [ 0.149, 0.149, 0.149, 1.0 ],
					"varname" : "out"
				}

			}
, 			{
				"box" : 				{
					"fontname" : "Arial",
					"fontsize" : 12.0,
					"hidden" : 1,
					"id" : "obj-3",
					"maxclass" : "newobj",
					"numinlets" : 1,
					"numoutlets" : 1,
					"outlettype" : [ "" ],
					"patching_rect" : [ 135.0, 168.0, 151.0, 22.0 ],
					"text" : "sprintf midichannel #1 %ld"
				}

			}
, 			{
				"box" : 				{
					"allowdrag" : 0,
					"arrow" : 0,
					"bgcolor" : [ 0.952941, 0.988235, 0.992157, 1.0 ],
					"bgfillcolor_angle" : 270.0,
					"bgfillcolor_color" : [ 0.952941, 0.988235, 0.992157, 1.0 ],
					"bgfillcolor_color1" : [ 0.376471, 0.384314, 0.4, 1.0 ],
					"bgfillcolor_color2" : [ 0.290196, 0.309804, 0.301961, 1.0 ],
					"bgfillcolor_proportion" : 0.39,
					"bgfillcolor_type" : "color",
					"hint" : "MIDI Channel",
					"id" : "obj-1",
					"items" : [ "**", ",", 1, ",", 2, ",", 3, ",", 4, ",", 5, ",", 6, ",", 7, ",", 8, ",", 9, ",", 10, ",", 11, ",", 12, ",", 13, ",", 14, ",", 15, ",", 16, ",", "MPE1-16", ",", "MPE1-8", ",", "MPE9-16", ",", "MPE1-4", ",", "MPE5-8", ",", "MPE9-12", ",", "MPE13-16", ",", "MPE1-2", ",", "MPE3-4", ",", "MPE5-6", ",", "MPE7-8", ",", "MPE9-10", ",", "MPE11-12", ",", "MPE13-14", ",", "MPE15-16" ],
					"maxclass" : "umenu",
					"numinlets" : 1,
					"numoutlets" : 3,
					"outlettype" : [ "int", "", "" ],
					"parameter_enable" : 0,
					"patching_rect" : [ 142.0, 0.0, 69.0, 22.0 ],
					"textcolor" : [ 0.149, 0.149, 0.149, 1.0 ],
					"types" : "-   ",
					"varname" : "midichannel"
				}

			}
, 			{
				"box" : 				{
					"fontname" : "Arial",
					"fontsize" : 12.0,
					"hidden" : 1,
					"id" : "obj-9",
					"maxclass" : "newobj",
					"numinlets" : 1,
					"numoutlets" : 1,
					"outlettype" : [ "" ],
					"patching_rect" : [ 18.0, 143.0, 106.0, 22.0 ],
					"text" : "sprintf gain #1 %lf"
				}

			}
, 			{
				"box" : 				{
					"bgcolor" : [ 1.0, 1.0, 1.0, 1.0 ],
					"fontname" : "Arial",
					"fontsize" : 12.0,
					"format" : 6,
					"hint" : "Gain",
					"id" : "obj-4",
					"maxclass" : "flonum",
					"maximum" : 20.0,
					"numinlets" : 1,
					"numoutlets" : 2,
					"outlettype" : [ "", "bang" ],
					"parameter_enable" : 0,
					"patching_rect" : [ 22.0, 0.0, 35.0, 22.0 ],
					"textcolor" : [ 0.0, 0.0, 0.0, 1.0 ],
					"triangle" : 0,
					"varname" : "gain"
				}

			}
, 			{
				"box" : 				{
					"fontname" : "Arial",
					"fontsize" : 12.0,
					"hidden" : 1,
					"id" : "obj-13",
					"maxclass" : "newobj",
					"numinlets" : 1,
					"numoutlets" : 1,
					"outlettype" : [ "" ],
					"patching_rect" : [ 69.0, 23.0, 125.0, 22.0 ],
					"text" : "sprintf output #1 C%s"
				}

			}
, 			{
				"box" : 				{
					"fontname" : "Arial",
					"fontsize" : 12.0,
					"hidden" : 1,
					"id" : "obj-11",
					"maxclass" : "newobj",
					"numinlets" : 1,
					"numoutlets" : 0,
					"patching_rect" : [ 69.0, 402.0, 119.0, 22.0 ],
					"text" : "s contimbre_eplayer"
				}

			}
, 			{
				"box" : 				{
					"bgcolor" : [ 0.988235, 0.992157, 0.94902, 1.0 ],
					"hint" : "VU Meter",
					"id" : "obj-42",
					"ignoreclick" : 1,
					"maxclass" : "multislider",
					"numinlets" : 1,
					"numoutlets" : 2,
					"orientation" : 0,
					"outlettype" : [ "", "" ],
					"parameter_enable" : 0,
					"patching_rect" : [ 212.0, 0.0, 111.0, 22.0 ],
					"presentation" : 1,
					"presentation_rect" : [ 1118.0, 207.0, 117.0, 48.0 ],
					"setminmax" : [ 0.0, 70.0 ],
					"setstyle" : 1,
					"slidercolor" : [ 0.419608, 0.760784, 0.94902, 1.0 ],
					"spacing" : 1,
					"varname" : "vu"
				}

			}
, 			{
				"box" : 				{
					"bgcolor" : [ 0.890196, 0.768627, 0.960784, 1.0 ],
					"hint" : "MIDI Activity",
					"id" : "obj-2",
					"ignoreclick" : 1,
					"maxclass" : "led",
					"numinlets" : 1,
					"numoutlets" : 1,
					"offcolor" : [ 0.513726, 0.917647, 0.533333, 1.0 ],
					"oncolor" : [ 0.098039, 0.784314, 0.337255, 1.0 ],
					"outlettype" : [ "int" ],
					"parameter_enable" : 0,
					"patching_rect" : [ 0.0, 0.0, 20.0, 20.0 ],
					"varname" : "midi_activity"
				}

			}
 ],
		"lines" : [ 			{
				"patchline" : 				{
					"destination" : [ "obj-3", 0 ],
					"hidden" : 1,
					"source" : [ "obj-1", 0 ]
				}

			}
, 			{
				"patchline" : 				{
					"destination" : [ "obj-13", 0 ],
					"hidden" : 1,
					"source" : [ "obj-12", 1 ]
				}

			}
, 			{
				"patchline" : 				{
					"destination" : [ "obj-11", 0 ],
					"hidden" : 1,
					"source" : [ "obj-13", 0 ]
				}

			}
, 			{
				"patchline" : 				{
					"destination" : [ "obj-6", 0 ],
					"hidden" : 1,
					"source" : [ "obj-16", 0 ]
				}

			}
, 			{
				"patchline" : 				{
					"destination" : [ "obj-11", 0 ],
					"hidden" : 1,
					"midpoints" : [ 108.5, 121.5, 78.5, 121.5 ],
					"source" : [ "obj-17", 0 ]
				}

			}
, 			{
				"patchline" : 				{
					"destination" : [ "obj-11", 0 ],
					"hidden" : 1,
					"midpoints" : [ 144.5, 226.0, 78.5, 226.0 ],
					"source" : [ "obj-3", 0 ]
				}

			}
, 			{
				"patchline" : 				{
					"destination" : [ "obj-9", 0 ],
					"hidden" : 1,
					"source" : [ "obj-4", 0 ]
				}

			}
, 			{
				"patchline" : 				{
					"destination" : [ "obj-17", 0 ],
					"hidden" : 1,
					"source" : [ "obj-6", 0 ]
				}

			}
, 			{
				"patchline" : 				{
					"destination" : [ "obj-11", 0 ],
					"hidden" : 1,
					"midpoints" : [ 27.5, 226.5, 78.5, 226.5 ],
					"source" : [ "obj-9", 0 ]
				}

			}
 ],
		"dependency_cache" : [  ],
		"autosave" : 0,
		"bgcolor" : [ 0.999, 0.9, 0.968438, 1.0 ]
	}

}
