// 0 18 plusbox
// 17 17 checkbox
// 33 159 voicename
// 191 335 instrumentmodes
// 526 41 solomute
// 567 overall length
sketch.ortho3d(); //like default3d but uses orthographic projection

var colors = new Array(
               new Array(.42,.76,.95),
               new Array(.96,.44,.48),
               new Array(.76,.82,.57),
               new Array(.92,.94,.67),
               new Array(.93,.58,1.00),
               new Array(.93,.36,.87),
               new Array(.28,.92,.84),
               new Array(.95,.91,.41)
);
var current_colors = new Array(3);
var color_index    =            0;
var width = box.rect[2] - box.rect[0];
var height = box.rect[3] - box.rect[1];
var aspect = width/height;
var current_text;
var my_number=0;
    
var color_factor = 0.85;
var selected=false;
var dx_maxbox=18;
var is_idle=false;
var old_box = -1;
var ystart = -1;
var yend   =  1;

for (var i=0;i<colors.length;i++)
{
  for (var j=0;j<3;j++)
  {
      colors[i][j]=(1-(1-colors[i][j])*color_factor)
  }
}
    
function convert_x(lx)
{
  return((lx/width*2-1)*aspect);
}
    
var xlight = 0.05;
var ylight = 0.5;
var zlight = 2.0;
var alight = 0.0;

function text(ltext)
{
  current_text=ltext;
  var dx=3;
  var dy=.2;
  var dz=0.3;
    with (sketch) {
        glclearcolor(0.999, 0.9, 0.968438);
        glclear();  
        glloadidentity();          
        gllight(0,"position",xlight,ylight,zlight,alight);
        if ((is_idle)&&(!selected))
        {
            current_colors[0]=1-(1-colors[color_index][0])*.8;
            current_colors[1]=1-(1-colors[color_index][1])*.8;
            current_colors[2]=1-(1-colors[color_index][2])*.8;
        }
        if ((!is_idle)&&(!selected))
        {
            current_colors[0]=colors[color_index][0];
            current_colors[1]=colors[color_index][1];
            current_colors[2]=colors[color_index][2];
        }
        if (selected)
        {
            current_colors[0]=colors[color_index][0]*.5;
            current_colors[1]=colors[color_index][1]*.5;
            current_colors[2]=colors[color_index][2]*.5;
        }
        glcolor(current_colors);
          quad(
            convert_x(0),ystart,0,
            convert_x(width),ystart,0,
            convert_x(width-dx),ystart+dy,dz,
            convert_x(dx),ystart+dy,dz
            );
            //top
          quad(
            convert_x(0),yend,0,
            convert_x(width),yend,0,
            convert_x(width-dx),yend-dy,dz,
            convert_x(dx),yend-dy,dz
            );
            //left
          quad(
            convert_x(0),ystart,0,
            convert_x(dx),ystart+dy,dz,
            convert_x(dx),yend-dy,dz,
            convert_x(0),yend,0
            );
            //right
          quad(
            convert_x(width),yend,0,
            convert_x(width-dx),yend-dy,dz,
            convert_x(width-dx),ystart+dy,dz,
            convert_x(width),ystart,0
            );
          // area
          quad(
            convert_x(dx),ystart+dy,dz,
            convert_x(width-dx),ystart+dy,dz,
            convert_x(width-dx),yend-dy,dz,
            convert_x(dx),yend-dy,dz
          );

          font("Sans Serif");
          fontsize(12);                  
          if (selected)
            glcolor(1,1,1);
          else
            glcolor(0,0,0);
          textalign("left","center");
          moveto(convert_x(5,0));
          text(ltext);
          refresh();
    }         
}


function slight(lx,ly,lz,la)
{
  xlight = lx;
  ylight = ly;
  zlight = lz;
  alight = la;
  draw_voicename();
}
        
function onidle(x,y,but,cmd,shift,capslock,option,ctrl)
{
  is_idle=true;
  text(current_text);
}
        
function set_number(lnum)
{
  my_number = lnum;
    var owner; 
    var top_patcher= this.patcher;
    owner = this.patcher.parentpatcher; 
    while (owner) { 
        top_patcher = owner; 
        owner = owner.parentpatcher; 
    } 
    master_mxj = top_patcher.getnamed("core").subpatcher().getnamed("audio");
}
        
function bgcolor(lnum)
{
    color_index = lnum;
    text(current_text);
}
        
function onidleout(x,y,but,cmd,shift,capslock,option,ctrl)
{
    is_idle=false;
    text(current_text);
    if (selected)
    {
        var owner; 
        var top_patcher= this.patcher;
        owner = this.patcher.parentpatcher; 
        while (owner) { 
            top_patcher = owner; 
            owner = owner.parentpatcher; 
        } 
    master_mxj = top_patcher.getnamed("core").subpatcher().getnamed("audio");
        //may be we wanted to move voices, so give a sign to mxj
        master_mxj.message("voice_in_editor_idleout");
        return;
    }
}

function onclick(x,y,but,cmd,shift,capslock,option,ctrl)
{
    var top_patcher= this.patcher;
    owner = this.patcher.parentpatcher; 
    while (owner) { 
        top_patcher = owner; 
        owner = owner.parentpatcher; 
    } 
    master_mxj = top_patcher.getnamed("core").subpatcher().getnamed("audio");

    if ((!selected)&&(!cmd)&&(!shift)&&(!capslock)&&(!option)&&(!ctrl))
    {
        old_box = -1;
        master_mxj.message("open_program_editor",my_number);
    }
    // command
    if ((cmd)&&(!shift)&&(!capslock)&&(!option)&&(!ctrl))
    {
        selected = !selected;
        if (selected)
            master_mxj.message("select_voice_in_editor","click",my_number,1);
        else
            master_mxj.message("select_voice_in_editor","click",my_number,0);
        text(current_text);
    }
    // shift
    if ((!cmd)&&(shift)&&(!capslock)&&(!option)&&(!ctrl))
    {
        selected = true;
        master_mxj.message("select_voice_in_editor","drag",my_number,1);
        text(current_text);
    }
}

function select(lselect)
{
    selected = (lselect!=0);
    text(current_text);
}

function ondrag(x,y,button,cmd,shift,capslock,option,mod2)
{
    var current_box = my_number + Math.floor(y/dx_maxbox);
    if (old_box!=current_box)
    {
        old_box=current_box;
        if ((shift)&&(!capslock)&&(!option))
        {
            var owner; 
            var top_patcher= this.patcher;
            owner = this.patcher.parentpatcher; 
            while (owner) { 
                top_patcher = owner; 
                owner = owner.parentpatcher; 
            } 
    master_mxj = top_patcher.getnamed("core").subpatcher().getnamed("audio");
            master_mxj.message("select_voice_in_editor","drag",current_box,1);
            return;
        }
    }
    current_box = my_number + Math.floor(y/dx_maxbox-0.5);
    if (old_box!=current_box)
    {
        if ((selected)&&(!shift)&&(!cmd))
        {
            old_box=current_box;
            var owner; 
            var top_patcher= this.patcher;
            owner = this.patcher.parentpatcher; 
            while (owner) { 
                top_patcher = owner; 
                owner = owner.parentpatcher; 
            } 
    master_mxj = top_patcher.getnamed("core").subpatcher().getnamed("audio");
            master_mxj.message("want_to_move_voices_to",current_box);
            return;
        }
    }
}

function no_space()
{
    ystart = -1;
    yend   =  1;
    text(current_text);
}

function give_space_below()
{
    ystart = -.85;
    yend   =    1;
    text(current_text);
}

function give_space_above()
{
    ystart =  -1;
    yend   = .85;
    text(current_text);
}


