var editor_patcher;
var master_mxj;
var top_patcher;
var edit_instruments;
var delay_message_task;
var umenu_path = new Array();
var umenu_items = new Array();
var umenu = new Array();
var umenu_done_counter = new Array();
var umenu_index = new Array();

function init (lmaximal_number_of_programs)
{
  top_patcher         = this.patcher;
  var editor          = top_patcher.getnamed("contimbre_sampler_editor");
  editor_patcher      = editor.subpatcher();
  master_mxj           = top_patcher.getnamed("contimbre_sampler_master");
  edit_instruments  = editor_patcher.getnamed("instruments");
}

function umenu_address_start()
{
  umenu_path.push(new Array());
  umenu_items.push(new Array());
}

function umenu_address(lpathitem)
{
  umenu_path[umenu_path.length-1].push(lpathitem);
}

function umenu_start()
{
  var lpatcher = top_patcher;
  for (i=0;i<umenu_path.length;i++)
  {
    var lobject = lpatcher.getnamed(umenu_path[i]);
    lpatcher=lobject.subpatcher();
  }
  umenu.push(lobject);
}

function umenu_item(litem)
{
  umenu_items[umenu_path.length-1].push(litem);
}

function build_umenu(ltasknumber)
{
  if (umenu_done_counter[ltasknumber]<0) 
  {
    umenu[ltasknumber].message("clear");
    post("clear "+ltasknumber+"\n");
  }
  umenu_done_counter[ltasknumber]++;
}

function umenu_index(lindex)
{
  umenu_index.push(lindex);
  umenu_done_counter.push(-1);
  umenu_task=new Task(build_umenu,this,(umenu_path.length-1));
  umenu_task.interval=0;
  umenu_task.repeat(umenu_items[umenu_path.length-1]+3); //steps are: clear, nitems, setcheck, set = nitems+3
}

function send_delayed_message(args)
{
    master_mxj.message(args);
}

function delay_message(lstring)
{
  args=new Array(arguments.length);
  for (var i=0;i<arguments.length;i++)
  {
      args[i]=arguments[i];
  }
  delay_message_task=new Task(send_delayed_message,this,args);
  delay_message_task.schedule(0);
}
